# 后端应用部署指南

## 环境要求
- Node.js 18+
- PostgreSQL 12+
- Redis 6+
- MinIO（可选，用于文件存储）
- PM2（用于进程管理）

## 快速部署（使用PM2）

### 1. 解压文件
```bash
tar -xzf backend_*.tar.gz
cd backend
```

### 2. 安装PM2（全局）
```bash
npm install -g pm2
```

### 3. 启动应用
```bash
pm2 start ecosystem.config.js --env production
```

### 4. 查看应用状态
```bash
pm2 status
pm2 logs app-portfolio-backend
```

### 5. 停止应用
```bash
pm2 stop app-portfolio-backend
```

### 6. 重启应用
```bash
pm2 restart app-portfolio-backend
```

### 7. 删除应用
```bash
pm2 delete app-portfolio-backend
```

## 传统部署（不使用PM2）

### 1. 解压文件
```bash
tar -xzf backend_*.tar.gz
cd backend
```

### 2. 启动应用
```bash
./start.sh
```

或者使用 npm 启动
```bash
npm start
```

## PM2 常用命令

```bash
# 查看所有进程
pm2 list

# 查看进程详细信息
pm2 show app-portfolio-backend

# 查看实时日志
pm2 logs app-portfolio-backend

# 查看错误日志
pm2 logs app-portfolio-backend --err

# 监控进程
pm2 monit

# 保存进程列表（开机自启）
pm2 save

# 恢复进程列表
pm2 resurrect

# 清空所有进程
pm2 kill
```

## 开机自启配置

### Linux/Mac
```bash
pm2 startup
pm2 save
```

### Windows
```bash
pm2 install pm2-windows-startup
pm2 save
```

## Docker 部署

如果使用 Docker，可以使用以下 Dockerfile：

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --omit=dev

COPY src ./src
COPY .env ./

EXPOSE 8000

CMD ["node", "src/index.js"]
```

构建镜像：
```bash
docker build -t backend:latest .
```

运行容器：
```bash
docker run -d \
  --name backend \
  -p 8000:8000 \
  backend:latest
```

## 常见问题

### 数据库连接失败
- 检查 .env 中的数据库配置
- 确保 PostgreSQL 服务正在运行
- 检查防火墙设置

### Redis 连接失败
- 确保 Redis 服务正在运行
- 检查 .env 中的 Redis 配置

### 文件上传失败
- 检查 MinIO 配置
- 确保有足够的磁盘空间

### PM2 启动失败
- 检查 Node.js 版本是否 >= 18
- 检查 ecosystem.config.js 配置是否正确
- 查看 PM2 日志：`pm2 logs app-portfolio-backend`

## 监控和日志

### 日志文件位置
- 应用日志：`/app/backend/logs/out.log`
- 错误日志：`/app/backend/logs/error.log`

### 查看日志
```bash
# 查看最后100行日志
tail -100 /app/backend/logs/out.log

# 实时查看日志
tail -f /app/backend/logs/out.log

# 查看错误日志
tail -f /app/backend/logs/error.log
```

## 性能优化

### 集群模式
如果需要使用多个进程，修改 ecosystem.config.js 中的 instances：
```javascript
instances: 'max',  // 使用所有CPU核心
exec_mode: 'cluster',  // 使用集群模式
```

### 内存限制
默认配置限制最大内存为 500M，可根据需要调整：
```javascript
max_memory_restart: '1G',  // 修改为1GB
```
